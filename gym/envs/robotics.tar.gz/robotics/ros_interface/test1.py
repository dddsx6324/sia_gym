
import rospy

from sia_7f_arm_ros import SIA7FARMROS

sia_7f_arm_ros = SIA7FARMROS()
